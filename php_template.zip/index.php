<?php
require_once __DIR__ . '/inc/all.php';

render(__DIR__ . '/views/index.view.php');