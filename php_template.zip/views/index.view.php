<section>
    <h1>Willkommen</h1>
    <p>Dies ist eine Bespiel-Sektion um die Projektstruktur zu testen</p>
</section>